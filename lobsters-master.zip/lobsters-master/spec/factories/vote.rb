FactoryBot.define do
  factory :vote do
    vote { 1 }
  end
end
